# Database Configuration
DATABASE_URI = None
DATABASE_NAME = None

# Bot Configuration
BOT_TOKEN = None
REDIS_CONF = {}

# DBL
DBL_TOKEN = None
DBL_SECRET = None

# Webhooks
STRIPE_KEY = None
STRIPE_WEBHOOK_SECRET = None
GITHUB_WEBHOOK_SECRET = None
